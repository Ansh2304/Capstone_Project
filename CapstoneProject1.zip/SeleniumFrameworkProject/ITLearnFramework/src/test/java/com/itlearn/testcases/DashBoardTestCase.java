package com.itlearn.testcases;

import org.testng.annotations.Test;

import com.itlearn.pages.BaseTest;
import com.itlearn.pages.DashBoardPage;
import com.itlearn.pages.LoginPage;
import com.itlearn.utility.ReadExcelFile;

public class DashBoardTestCase extends BaseTest {
	
	
	String fileName=System.getProperty("user.dir")+"\\TestData\\TestPortalData.xlsx";
	
	//this will excute first
	@Test(priority =1)
	void testcourses()
	
	{
		//object of loginpage
		LoginPage lp=new LoginPage(driver);
		
		//read the values from excelfile
		String username=ReadExcelFile.getCellValue(fileName, "LoginData", 1, 0);//row 1, coloumn 0
		String password=ReadExcelFile.getCellValue(fileName, "LoginData", 1, 1);//row 1, coloumn 1
		
		//called the method from loginpage
		lp.loginToPortal(username, password);
		
		//create the object of dashboardpage
		DashBoardPage dp = new DashBoardPage(driver);
		
		//calling the method from dashboardpage
		dp.dashboardClick();
		
	}

}
